package quiz;
import java.util.Scanner;
public class IOHandling {
    private Scanner in = new Scanner(System.in);
    private Game game;

    public IOHandling(){
        game = new Game();
    }

    public void printQuestion(String question){
        System.out.println("\n" + question);
        
    }

    public String getAnswer() {
        String answer = in.nextLine().toLowerCase();
        return answer;
    }

    public void printScore(int scoreRoundone, int scoreRoundtwo, int totalScore) {
        System.out.println("Here is your score:");
        System.out.println(String.format("You scored %d out of %d points in the first round.", scoreRoundone, totalScore));
        System.out.println(String.format("You scored %d out of %d in the second round.", scoreRoundtwo, totalScore-scoreRoundone));
        System.out.println(String.format("%d points were missed in total.", totalScore-scoreRoundone-scoreRoundtwo));
    } 

    public void startGame(){
        game.exampleQuestions();

        for (Question q: game.getQuestions()){
            printQuestion(q.toString());
            if(game.checkAnswer(q,getAnswer())){
                game.addScoreRound(1, q.getScore());}
            
            else{
                game.getWrongQuestions().add(q);
            }
        }

        System.out.println("We are moving on to round 2 which will consist of questions you previously answered incorrectly.");

        for(Question q2: game.getWrongQuestions()){
            printQuestion(q2.toString());
            if(game.checkAnswer(q2, getAnswer()))
                game.addScoreRound(2, q2.getScore());
        }

        printScore(game.getScoreRound(1),game.getScoreRound(2), game.getTotalScore());

    }
}
    



