package quiz;

public class Main {

	public static void main(String[] args) {
		IOHandling quiz = new IOHandling();
		quiz.startGame();
	}

}